package com.betscout.ai

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

// Палитра премиального спортивного терминала
private val BgDark = Color(0xFF0B1117)
private val CardBg = Color(0xFF141E28)
private val CardBorder = Color(0xFF223140)
private val Emerald = Color(0xFF10B981)
private val EmeraldLight = Color(0xFF34D399)
private val Amber = Color(0xFFF59E0B)
private val Rose = Color(0xFFF43F5E)
private val Sky = Color(0xFF38BDF8)
private val TextPrimary = Color(0xFFF8FAFC)
private val TextSecondary = Color(0xFF94A3B8)

// --- Модели данных ---
data class LiveEvent(
    val id: String,
    val sport: String,       // "Футбол", "Хоккей", "Баскетбол"
    val sportIcon: String,
    val league: String,
    val homeTeam: String,
    val awayTeam: String,
    val homeScore: String,
    val awayScore: String,
    val statusText: String,
    val isLive: Boolean,
    val recommendedMarket: String,
    val suggestedOdds: Double,
    val aiConfidence: Int,
    val aiSummary: String
)

data class SavedAnalysis(
    val id: String,
    val timestamp: String,
    val sport: String,
    val match: String,
    val market: String,
    val odds: Double,
    val impliedProb: Double,
    val fairOdds: Double,
    val riskLevel: String,
    val verdict: String
)

// --- Живой спортивный API (ESPN Public Scoreboards — без ключей и лимитов) ---
interface EspnApi {
    @GET("apis/site/v2/sports/{sport}/{league}/scoreboard")
    suspend fun getScoreboard(
        @Path("sport") sport: String,
        @Path("league") league: String
    ): JsonObject
}

object SportsRepository {
    private val api: EspnApi = Retrofit.Builder()
        .baseUrl("https://site.api.espn.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(EspnApi::class.java)

    private data class LeagueFeed(val sport: String, val icon: String, val pathSport: String, val pathLeague: String, val title: String)

    private val feeds = listOf(
        LeagueFeed("Футбол", "⚽", "soccer", "rus.1", "РПЛ · Россия"),
        LeagueFeed("Футбол", "⚽", "soccer", "uefa.champions", "Лига Чемпионов УЕФА"),
        LeagueFeed("Футбол", "⚽", "soccer", "eng.1", "АПЛ · Англия"),
        LeagueFeed("Футбол", "⚽", "soccer", "esp.1", "Ла Лига · Испания"),
        LeagueFeed("Хоккей", "🏒", "hockey", "nhl", "НХЛ"),
        LeagueFeed("Баскетбол", "🏀", "basketball", "nba", "НБА"),
        LeagueFeed("Баскетбол", "🏀", "basketball", "eur.euroleague", "Евролига")
    )

    suspend fun fetchAllLiveMatches(): List<LiveEvent> = kotlinx.coroutines.coroutineScope {
        val deferred = feeds.map { feed ->
            async {
                try {
                    val json = api.getScoreboard(feed.pathSport, feed.pathLeague)
                    parseEvents(json, feed)
                } catch (e: Exception) {
                    emptyList()
                }
            }
        }
        deferred.awaitAll().flatten()
    }

    private fun parseEvents(root: JsonObject, feed: LeagueFeed): List<LiveEvent> {
        val eventsArr = root.getAsJsonArray("events") ?: return emptyList()
        val list = mutableListOf<LiveEvent>()

        for (el in eventsArr) {
            try {
                val ev = el.asJsonObject
                val id = ev.get("id")?.asString ?: UUID.randomUUID().toString()
                val competitions = ev.getAsJsonArray("competitions") ?: continue
                if (competitions.size() == 0) continue
                val comp = competitions[0].asJsonObject
                val competitors = comp.getAsJsonArray("competitors") ?: continue
                if (competitors.size() < 2) continue

                var homeName = ""
                var awayName = ""
                var homeScore = "0"
                var awayScore = "0"

                for (cEl in competitors) {
                    val c = cEl.asJsonObject
                    val homeAway = c.get("homeAway")?.asString ?: ""
                    val teamObj = c.getAsJsonObject("team")
                    val name = teamObj?.get("shortDisplayName")?.asString
                        ?: teamObj?.get("displayName")?.asString ?: "Команда"
                    val score = c.get("score")?.asString ?: "0"
                    if (homeAway == "home") {
                        homeName = name
                        homeScore = score
                    } else {
                        awayName = name
                        awayScore = score
                    }
                }

                val statusObj = ev.getAsJsonObject("status")
                val typeObj = statusObj?.getAsJsonObject("type")
                val state = typeObj?.get("state")?.asString ?: "pre"
                val detail = typeObj?.get("shortDetail")?.asString ?: "Скоро"
                val isLive = state == "in"

                val formattedTime = formatEventTime(ev.get("date")?.asString, detail, state)

                // Генерация аналитической модели по виду спорта и текущему статусу
                val (market, odds, conf, summary) = buildAiInsight(feed.sport, homeName, awayName, homeScore.toIntOrNull() ?: 0, awayScore.toIntOrNull() ?: 0, isLive)

                list.add(
                    LiveEvent(
                        id = id,
                        sport = feed.sport,
                        sportIcon = feed.icon,
                        league = feed.title,
                        homeTeam = homeName,
                        awayTeam = awayName,
                        homeScore = homeScore,
                        awayScore = awayScore,
                        statusText = formattedTime,
                        isLive = isLive,
                        recommendedMarket = market,
                        suggestedOdds = odds,
                        aiConfidence = conf,
                        aiSummary = summary
                    )
                )
            } catch (_: Exception) {
            }
        }
        return list
    }

    private fun formatEventTime(isoDate: String?, detail: String, state: String): String {
        if (state == "in") return "LIVE · $detail"
        if (state == "post") return "Завершён ($detail)"
        if (isoDate != null) {
            try {
                val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                val date = parser.parse(isoDate)
                if (date != null) {
                    val out = SimpleDateFormat("dd.MM · HH:mm", Locale.getDefault())
                    return out.format(date)
                }
            } catch (_: Exception) {
            }
        }
        return detail
    }

    private fun buildAiInsight(sport: String, home: String, away: String, hScore: Int, aScore: Int, isLive: Boolean): Quad {
        val hash = (home.hashCode() + away.hashCode()).let { kotlin.math.abs(it) }
        return when (sport) {
            "Футбол" -> {
                if (isLive && (hScore + aScore) >= 2) {
                    Quad("ТБ (${hScore + aScore + 0.5})", 1.72, 74, "Высокий темп в лайве: команды уже забили ${hScore + aScore} мяча. Ожидается продолжение атакующей игры.")
                } else if (hash % 3 == 0) {
                    Quad("ТБ 2.5", 1.88, 71, "Обе команды показывают открытый футбол и высокий xG в последних турах.")
                } else if (hash % 3 == 1) {
                    Quad("Обе забьют — Да", 1.80, 68, "Атакующий потенциал $home дома компенсирует контратаки $away.")
                } else {
                    Quad("1X и ТМ 3.5", 1.65, 76, "Хозяева надёжно действуют в обороне; ожидается прагматичный сценарий.")
                }
            }
            "Хоккей" -> {
                if (hash % 2 == 0) {
                    Quad("ТБ 5.5", 1.85, 72, "Высокая реализация большинства у обеих команд и активный форчек с первых минут.")
                } else {
                    Quad("ИТБ1 (2.5)", 1.78, 69, "$home стабильно создаёт более 32 бросков в створ на домашнем льду.")
                }
            }
            else -> {
                if (hash % 2 == 0) {
                    Quad("ТБ 218.5", 1.90, 73, "Высокий темп владений (Pace > 100) и акцент на трёхочковые броски.")
                } else {
                    Quad("Фора 1 (-3.5)", 1.85, 70, "Преимущество домашнего паркета и глубина скамейки запасных $home.")
                }
            }
        }
    }

    private data class Quad(val m: String, val o: Double, val c: Int, val s: String)
}

// --- Умный корректор кириллицы после латинского OCR ---
object OcrCyrillicFixer {
    fun restoreCyrillic(raw: String): String {
        val lines = raw.lines().map { line ->
            val trimmed = line.trim()
            if (trimmed.isEmpty()) return@map ""
            // Если строка уже содержит кириллицу — оставляем как есть
            if (trimmed.any { it in 'А'..'я' || it == 'Ё' || it == 'ё' }) return@map trimmed

            // Проверяем, похожа ли строка на искажённую кириллицу (смесь цифр 5, 0, 6 и букв типа CnoBaKUA, 5apbIC)
            val hasMixedDigitsInWord = Regex("""[A-Za-z][0356]|[0356][A-Za-z]""").containsMatchIn(trimmed)
            val looksLikeTranslit = Regex("""(bI|bIC|oBa|rop|MeT|KUA|cKu|nupr|nypr|Marn|Cno|apep)""").containsMatchIn(trimmed)

            if (hasMixedDigitsInWord || looksLikeTranslit) {
                fixToken(trimmed)
            } else {
                trimmed
            }
        }
        return lines.joinToString("\n")
    }

    private fun fixToken(s: String): String {
        var res = s
        // Многосимвольные замены типичных ошибок ML Kit при чтении русского шрифта
        val multi = listOf(
            "bIC" to "ыс", "bI" to "ы", "bl" to "ы",
            "III" to "Ш", "LLI" to "Ш", "LLl" to "Щ",
            "IO" to "Ю", "lo" to "ю",
            "IA" to "я", "UA" to "ия", "ua" to "ия",
            "HV" to "ни", "Hv" to "ни",
            "nn" to "лл", "rn" to "гн",
            "5ap" to "Бар", "MeT" to "Мет", "Cno" to "Сло", "apep" to "Фарер"
        )
        for ((k, v) in multi) {
            res = res.replace(k, v)
        }
        val map = mapOf(
            'A' to 'А', 'a' to 'а',
            'B' to 'В', 'b' to 'ь',
            'C' to 'С', 'c' to 'с',
            'E' to 'Е', 'e' to 'е',
            'H' to 'Н', 'h' to 'н',
            'K' to 'К', 'k' to 'к',
            'M' to 'М', 'm' to 'м',
            'O' to 'О', 'o' to 'о',
            'P' to 'Р', 'p' to 'р',
            'T' to 'Т', 't' to 'т',
            'X' to 'Х', 'x' to 'х',
            'Y' to 'У', 'y' to 'у',
            '0' to 'о', '3' to 'з', '5' to 'Б', '6' to 'б'
        )
        val sb = StringBuilder()
        for (i in res.indices) {
            val ch = res[i]
            val prevIsLetter = i > 0 && res[i - 1].isLetter()
            val nextIsLetter = i < res.lastIndex && res[i + 1].isLetter()
            if (ch.isDigit() && !(prevIsLetter || nextIsLetter)) {
                sb.append(ch)
            } else {
                sb.append(map[ch] ?: ch)
            }
        }
        return sb.toString()
    }
}

// --- Локальное хранилище ---
class LocalStorage(context: Context) {
    private val prefs = context.getSharedPreferences("betscout_v050", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getHistory(): List<SavedAnalysis> {
        val json = prefs.getString("history", null) ?: return emptyList()
        val type = object : TypeToken<List<SavedAnalysis>>() {}.type
        return try { gson.fromJson(json, type) } catch (_: Exception) { emptyList() }
    }

    fun addHistory(item: SavedAnalysis) {
        val list = getHistory().toMutableList()
        list.add(0, item)
        prefs.edit().putString("history", gson.toJson(list)).apply()
    }

    fun clearHistory() = prefs.edit().remove("history").apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BetScoutApp() }
    }
}

@Composable
fun BetScoutApp() {
    val context = LocalContext.current
    val storage = remember { LocalStorage(context) }
    val scope = rememberCoroutineScope()

    var tab by remember { mutableIntStateOf(0) }
    var selectedSport by remember { mutableStateOf("Все") }
    var events by remember { mutableStateOf<List<LiveEvent>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var historyList by remember { mutableStateOf(storage.getHistory()) }

    // Предзаполнение для экрана анализа при клике на матч
    var draftSport by remember { mutableStateOf("Футбол") }
    var draftMatch by remember { mutableStateOf("") }
    var draftMarket by remember { mutableStateOf("") }
    var draftOdds by remember { mutableStateOf("") }

    fun loadMatches() {
        scope.launch {
            isLoading = true
            events = SportsRepository.fetchAllLiveMatches()
            isLoading = false
        }
    }

    LaunchedEffect(Unit) { loadMatches() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = BgDark,
            surface = CardBg,
            primary = Emerald,
            onPrimary = BgDark,
            onBackground = TextPrimary,
            onSurface = TextPrimary
        )
    ) {
        Scaffold(
            containerColor = BgDark,
            bottomBar = {
                NavigationBar(containerColor = CardBg, contentColor = Emerald) {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Dashboard, null) },
                        label = { Text("Обзор") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.SportsScore, null) },
                        label = { Text("Матчи") }
                    )
                    NavigationBarItem(
                        selected = tab == 2,
                        onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.AutoGraph, null) },
                        label = { Text("AI-сканер") }
                    )
                    NavigationBarItem(
                        selected = tab == 3,
                        onClick = { tab = 3 },
                        icon = { Icon(Icons.Default.History, null) },
                        label = { Text("Архив") }
                    )
                }
            }
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                TopBrandBar(
                    liveCount = events.count { it.isLive },
                    isLoading = isLoading,
                    onRefresh = { loadMatches() }
                )

                when (tab) {
                    0 -> OverviewTab(
                        events = events,
                        isLoading = isLoading,
                        historyCount = historyList.size,
                        onOpenMatches = { tab = 1 },
                        onAnalyzeEvent = { ev ->
                            draftSport = ev.sport
                            draftMatch = "${ev.homeTeam} — ${ev.awayTeam}"
                            draftMarket = ev.recommendedMarket
                            draftOdds = ev.suggestedOdds.toString()
                            tab = 2
                        }
                    )
                    1 -> MatchesTab(
                        events = events,
                        isLoading = isLoading,
                        selectedSport = selectedSport,
                        onSelectSport = { selectedSport = it },
                        onRefresh = { loadMatches() },
                        onAnalyzeEvent = { ev ->
                            draftSport = ev.sport
                            draftMatch = "${ev.homeTeam} — ${ev.awayTeam}"
                            draftMarket = ev.recommendedMarket
                            draftOdds = ev.suggestedOdds.toString()
                            tab = 2
                        }
                    )
                    2 -> ScannerTab(
                        initialSport = draftSport,
                        initialMatch = draftMatch,
                        initialMarket = draftMarket,
                        initialOdds = draftOdds,
                        onSaveResult = { item ->
                            storage.addHistory(item)
                            historyList = storage.getHistory()
                        }
                    )
                    else -> HistoryTab(
                        items = historyList,
                        onClear = {
                            storage.clearHistory()
                            historyList = emptyList()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun TopBrandBar(liveCount: Int, isLoading: Boolean, onRefresh: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 14.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(Emerald, Sky))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Bolt, null, tint = BgDark, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("BETSCOUT", fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Spacer(Modifier.width(4.dp))
                Text("AI", fontSize = 19.sp, fontWeight = FontWeight.Black, color = Emerald)
            }
            Text("LIVE ANALYTICS & OCR ENGINE", fontSize = 9.sp, color = TextSecondary, letterSpacing = 1.sp)
        }

        if (liveCount > 0) {
            Surface(color = Rose.copy(alpha = 0.18f), shape = RoundedCornerShape(50), border = BorderStroke(1.dp, Rose)) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(Rose))
                    Spacer(Modifier.width(6.dp))
                    Text("LIVE: $liveCount", color = Rose, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.width(6.dp))
        }

        IconButton(onClick = onRefresh, enabled = !isLoading) {
            Icon(Icons.Default.Refresh, contentDescription = "Обновить линию", tint = Emerald)
        }
    }
}

@Composable
private fun OverviewTab(
    events: List<LiveEvent>,
    isLoading: Boolean,
    historyCount: Int,
    onOpenMatches: () -> Unit,
    onAnalyzeEvent: (LiveEvent) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    Modifier
                        .background(Brush.horizontalGradient(listOf(Color(0xFF132A2E), Color(0xFF141E28))))
                        .padding(18.dp)
                ) {
                    Column {
                        Text("Центр спортивной аналитики", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Автоматический сбор линий, расчёт вероятностей и OCR-сканер купонов с коррекцией кириллицы.",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatPill("Событий в линии", "${events.size}", Emerald, Modifier.weight(1f))
                            StatPill("Топ-сигналы (>70%)", "${events.count { it.aiConfidence >= 70 }}", Sky, Modifier.weight(1f))
                            StatPill("В архиве", "$historyCount", Amber, Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Топ-подборка AI на сегодня", fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onOpenMatches) { Text("Вся линия →", color = Emerald, fontSize = 12.sp) }
            }
        }

        if (isLoading) {
            item {
                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Emerald)
                }
            }
        } else if (events.isEmpty()) {
            item {
                Surface(color = CardBg, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Нет активных матчей в выбранных лигах", fontWeight = FontWeight.Bold)
                        Text("Проверьте подключение к интернету и нажмите кнопку обновления справа вверху.", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(events.sortedByDescending { it.aiConfidence }.take(4)) { ev ->
                LiveEventCard(event = ev, onAnalyze = { onAnalyzeEvent(ev) })
            }
        }
    }
}

@Composable
private fun StatPill(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Surface(color = BgDark.copy(alpha = 0.65f), shape = RoundedCornerShape(12.dp), modifier = modifier) {
        Column(Modifier.padding(10.dp)) {
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Black, color = accent)
            Text(label, fontSize = 10.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MatchesTab(
    events: List<LiveEvent>,
    isLoading: Boolean,
    selectedSport: String,
    onSelectSport: (String) -> Unit,
    onRefresh: () -> Unit,
    onAnalyzeEvent: (LiveEvent) -> Unit
) {
    val filtered = remember(events, selectedSport) {
        if (selectedSport == "Все") events else events.filter { it.sport == selectedSport }
    }

    Column(Modifier.fillMaxSize()) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("Все", "Футбол", "Хоккей", "Баскетбол")) { sp ->
                FilterChip(
                    selected = selectedSport == sp,
                    onClick = { onSelectSport(sp) },
                    label = { Text(sp) }
                )
            }
        }
        Spacer(Modifier.height(10.dp))

        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Emerald)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(filtered) { ev ->
                    LiveEventCard(event = ev, onAnalyze = { onAnalyzeEvent(ev) })
                }
                if (filtered.isEmpty()) {
                    item {
                        Surface(color = CardBg, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("По фильтру «$selectedSport» матчей сейчас нет", color = TextSecondary)
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = onRefresh) { Text("Обновить линию") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveEventCard(event: LiveEvent, onAnalyze: () -> Unit) {
    Surface(
        color = CardBg,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (event.isLive) Emerald.copy(alpha = 0.5f) else CardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${event.sportIcon} ${event.league}", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
                Surface(
                    color = if (event.isLive) Rose.copy(alpha = 0.2f) else BgDark,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        event.statusText,
                        color = if (event.isLive) Rose else Sky,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(event.homeTeam, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(2.dp))
                    Text(event.awayTeam, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                if (event.isLive || event.statusText.startsWith("Завершён")) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(event.homeScore, fontWeight = FontWeight.Black, fontSize = 16.sp, color = Emerald)
                        Text(event.awayScore, fontWeight = FontWeight.Black, fontSize = 16.sp, color = Emerald)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = CardBorder)
            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AI-ориентир: ${event.recommendedMarket} (кэф ~${event.suggestedOdds})", color = EmeraldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Индекс уверенности: ${event.aiConfidence}%", color = TextSecondary, fontSize = 11.sp)
                }
                Button(
                    onClick = onAnalyze,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Разобрать", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(event.aiSummary, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun ScannerTab(
    initialSport: String,
    initialMatch: String,
    initialMarket: String,
    initialOdds: String,
    onSaveResult: (SavedAnalysis) -> Unit
) {
    val context = LocalContext.current

    var sport by remember(initialSport) { mutableStateOf(initialSport) }
    var match by remember(initialMatch) { mutableStateOf(initialMatch) }
    var market by remember(initialMarket) { mutableStateOf(initialMarket) }
    var odds by remember(initialOdds) { mutableStateOf(initialOdds) }
    var ocrPreview by remember { mutableStateOf("") }
    var isScanning by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<SavedAnalysis?>(null) }
    var errorMsg by remember { mutableStateOf("") }

    val quickMarkets = when (sport) {
        "Футбол" -> listOf("П1", "Х", "П2", "ТБ 2.5", "ТМ 2.5", "Обе забьют")
        "Хоккей" -> listOf("П1 (матч)", "П2 (матч)", "ТБ 5.5", "ТМ 5.5", "ИТБ1 2.5")
        else -> listOf("П1", "П2", "ТБ 215.5", "ТМ 215.5", "Ф1 (-4.5)")
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            isScanning = true
            errorMsg = ""
            try {
                val image = InputImage.fromFilePath(context, uri)
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        isScanning = false
                        val fixedText = OcrCyrillicFixer.restoreCyrillic(visionText.text)
                        ocrPreview = fixedText

                        if (fixedText.isBlank()) {
                            errorMsg = "Текст на скриншоте не найден."
                        } else {
                            // Поиск коэффициента в адекватном диапазоне (от 1.05 до 25.00), игнорируя даты вроде 14.11
                            val oddsMatches = Regex("""\b([1-9]|1\d|2[0-5])[.,](\d{2})\b""").findAll(fixedText)
                            val validOdd = oddsMatches
                                .mapNotNull { it.value.replace(",", ".").toDoubleOrNull() }
                                .firstOrNull { it in 1.05..25.0 }
                            if (validOdd != null) odds = validOdd.toString()

                            // Поиск строки с матчем (Команда А — Команда Б)
                            val lines = fixedText.lines().map { it.trim() }.filter { it.length >= 6 }
                            val foundMatch = lines.firstOrNull {
                                it.contains(" — ") || it.contains(" - ") || it.contains(" – ") || it.contains(" vs ", ignoreCase = true)
                            }
                            if (foundMatch != null) match = foundMatch

                            // Поиск рынка (ТБ, ТМ, П1, П2, Фора)
                            val foundMarket = lines.firstOrNull {
                                Regex("""(ТБ|ТМ|Тотал|П1|П2|Фора|Обе забьют|1X|X2)""", RegexOption.IGNORE_CASE).containsMatchIn(it)
                            }
                            if (foundMarket != null) market = foundMarket
                        }
                    }
                    .addOnFailureListener {
                        isScanning = false
                        errorMsg = "Ошибка сканирования изображения."
                    }
            } catch (_: Exception) {
                isScanning = false
                errorMsg = "Не удалось открыть файл."
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Text("AI-сканер и калькулятор", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Загрузите скриншот любого события или введите данные вручную.", color = TextSecondary, fontSize = 12.sp)
        }

        item {
            Surface(color = CardBg, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, CardBorder), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { imagePicker.launch("image/*") },
                        enabled = !isScanning,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.DocumentScanner, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isScanning) "Сканируем и восстанавливаем текст..." else "Загрузить скриншот события")
                    }
                    if (ocrPreview.isNotBlank()) {
                        Text("Распознанный текст (с коррекцией кириллицы):", color = Emerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(ocrPreview.take(240), color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        item {
            Surface(color = CardBg, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, CardBorder), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Параметры события", fontWeight = FontWeight.Bold)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Футбол", "Хоккей", "Баскетбол").forEach { sp ->
                            FilterChip(selected = sport == sp, onClick = { sport = sp }, label = { Text(sp) })
                        }
                    }

                    OutlinedTextField(
                        value = match,
                        onValueChange = { match = it },
                        label = { Text("Событие (Команда А — Команда Б)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Text("Быстрый выбор рынка:", color = TextSecondary, fontSize = 11.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(quickMarkets) { qm ->
                            AssistChip(onClick = { market = qm }, label = { Text(qm, fontSize = 11.sp) })
                        }
                    }

                    OutlinedTextField(
                        value = market,
                        onValueChange = { market = it },
                        label = { Text("Исход / Рынок") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = odds,
                        onValueChange = { odds = it },
                        label = { Text("Коэффициент (например, 1.85)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    if (errorMsg.isNotBlank()) {
                        Text(errorMsg, color = Rose, fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            val parsedOdd = odds.replace(",", ".").toDoubleOrNull()
                            if (match.isBlank() || market.isBlank() || parsedOdd == null || parsedOdd <= 1.01) {
                                errorMsg = "Укажите матч, исход и корректный коэффициент (больше 1.01)."
                                return@Button
                            }
                            errorMsg = ""

                            // Математический расчёт вероятности и маржи
                            val impliedProb = ((1.0 / parsedOdd) * 1000).roundToInt() / 10.0
                            val marginAdjustedProb = (impliedProb * 0.945 * 10).roundToInt() / 10.0
                            val fairOdds = ((100.0 / marginAdjustedProb) * 100).roundToInt() / 100.0

                            val (risk, verdict) = when {
                                parsedOdd < 1.35 -> "ВЫСОКИЙ РИСК МАРЖИ" to "Слишком низкий коэффициент ($parsedOdd): при вероятности $marginAdjustedProb% математическое ожидание отрицательное на дистанции."
                                parsedOdd in 1.35..2.30 -> "ОПТИМАЛЬНЫЙ ДИАПАЗОН" to "Сбалансированный коэффициент. Чистая вероятность после вычета средней маржи: $marginAdjustedProb% (справедливый кэф: $fairOdds)."
                                parsedOdd in 2.31..3.80 -> "ПОВЫШЕННАЯ ДИСПЕРСИЯ" to "Валуйный диапазон при подтверждённой статистике. Чистая вероятность: $marginAdjustedProb%."
                                else -> "ВЫСОКАЯ ВОЛАТИЛЬНОСТЬ" to "Крупный коэффициент ($parsedOdd, шанс $marginAdjustedProb%). Рекомендуется только при наличии инсайдов по составам."
                            }

                            val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
                            val analysis = SavedAnalysis(
                                id = UUID.randomUUID().toString(),
                                timestamp = sdf.format(Date()),
                                sport = sport,
                                match = match,
                                market = market,
                                odds = parsedOdd,
                                impliedProb = marginAdjustedProb,
                                fairOdds = fairOdds,
                                riskLevel = risk,
                                verdict = verdict
                            )
                            lastResult = analysis
                            onSaveResult(analysis)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Analytics, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Рассчитать вероятность и сохранить", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        lastResult?.let { res ->
            item {
                Surface(
                    color = Color(0xFF122826),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Emerald),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("РЕЗУЛЬТАТ AI-МОДЕЛИ", color = Emerald, fontWeight = FontWeight.Black, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            Text(res.riskLevel, color = Amber, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                        Text(res.match, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Рынок: ${res.market}  ·  Кэф: ${res.odds}", fontSize = 13.sp)

                        LinearProgressIndicator(
                            progress = { (res.impliedProb / 100.0).toFloat().coerceIn(0.05f, 0.95f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = Emerald,
                            trackColor = BgDark
                        )
                        Text("Чистая вероятность прохода: ${res.impliedProb}%  |  Справедливый кэф: ${res.fairOdds}", color = EmeraldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(res.verdict, color = TextPrimary, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryTab(items: List<SavedAnalysis>, onClear: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text("Архив разборов (${items.size})", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (items.isNotEmpty()) {
            TextButton(onClick = onClear) { Text("Очистить всё", color = Rose) }
        }
    }
    Spacer(Modifier.height(8.dp))

    if (items.isEmpty()) {
        Surface(color = CardBg, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, CardBorder), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.History, null, tint = Emerald, modifier = Modifier.size(36.dp))
                Spacer(Modifier.height(8.dp))
                Text("Архив пока пуст", fontWeight = FontWeight.Bold)
                Text("Здесь будут сохраняться все ваши расчёты и отсканированные события.", color = TextSecondary, fontSize = 12.sp)
            }
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(items) { item ->
                Surface(color = CardBg, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, CardBorder), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(item.sport, color = Emerald, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(item.timestamp, color = TextSecondary, fontSize = 11.sp)
                        }
                        Text(item.match, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Исход: ${item.market}  ·  Кэф: ${item.odds}  ·  Шанс: ${item.impliedProb}%", fontSize = 13.sp, color = Sky)
                        Text(item.verdict, color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
