package com.betscout.ai

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import java.text.SimpleDateFormat
import java.util.*

private val Bg = Color(0xFF101820)
private val Panel = Color(0xFF1B2833)
private val Green = Color(0xFF55D995)
private val Muted = Color(0xFF9AAAB7)

data class Fixture(
    val id: String = "",
    val sport: String,
    val matchup: String,
    val league: String,
    val start: String,
    val market: String,
    val status: String,
    val explanation: String,
    val isDemo: Boolean = true
)

data class ApiMatch(
    val id: String,
    val sport: String,
    val home: String,
    val away: String,
    val competition: String,
    val start_time: String?,
    val data_complete: Boolean
)

data class MatchesResponse(val mode: String, val matches: List<ApiMatch>)
data class HealthResponse(val status: String, val service: String, val mode: String)

data class CouponDraftRequest(
    val bookmaker: String,
    val sport: String,
    val match: String,
    val market: String,
    val odds: Double,
    val source: String
)

data class CouponDraftResponse(
    val accepted: Boolean,
    val persisted: Boolean,
    val implied_probability: Double?,
    val decision: String?,
    val note: String
)

data class SavedAnalysis(
    val id: String,
    val date: String,
    val bookmaker: String,
    val sport: String,
    val match: String,
    val market: String,
    val odds: Double,
    val status: String,
    val note: String
)

interface BetScoutApi {
    @GET("health")
    suspend fun health(): HealthResponse

    @GET("matches")
    suspend fun getMatches(@Query("sport") sport: String? = null): MatchesResponse

    @POST("coupon/draft")
    suspend fun sendCouponDraft(@Body draft: CouponDraftRequest): CouponDraftResponse
}

fun createApi(baseUrl: String): BetScoutApi? {
    return try {
        val cleanUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        Retrofit.Builder()
            .baseUrl(cleanUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(BetScoutApi::class.java)
    } catch (e: Exception) {
        null
    }
}

class LocalStorage(context: Context) {
    private val prefs = context.getSharedPreferences("betscout_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getServerUrl(): String = prefs.getString("server_url", "http://192.168.1.100:8000/") ?: "http://192.168.1.100:8000/"
    fun saveServerUrl(url: String) = prefs.edit().putString("server_url", url).apply()

    fun getHistory(): List<SavedAnalysis> {
        val json = prefs.getString("history_list", null) ?: return emptyList()
        val type = object : TypeToken<List<SavedAnalysis>>() {}.type
        return try { gson.fromJson(json, type) } catch (e: Exception) { emptyList() }
    }

    fun addHistory(item: SavedAnalysis) {
        val current = getHistory().toMutableList()
        current.add(0, item)
        prefs.edit().putString("history_list", gson.toJson(current)).apply()
    }

    fun clearHistory() = prefs.edit().remove("history_list").apply()
}

private val fallbackFixtures = listOf(
    Fixture("1", "⚽", "Example FC — Sample United", "Football · Demo league", "19:30", "Total goals 2.5", "INSUFFICIENT_DATA", "Локальная демо-карточка. Подключите сервер в настройках (шестерёнка вверху)."),
    Fixture("2", "🏒", "Demo Hawks — Test Bears", "Hockey · Demo league", "20:00", "Total goals 5.5", "INSUFFICIENT_DATA", "Нет данных о вратарях и последних результатах."),
    Fixture("3", "🏀", "Sample City — Example Lakers", "Basketball · Demo league", "21:15", "Total points 215.5", "INSUFFICIENT_DATA", "Нет данных о травмах и темпе игры.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BetScoutApp() }
    }
}

@Composable
fun BetScoutApp() {
    val context = LocalContext.current
    val storage = remember { LocalStorage(context) }
    val scope = rememberCoroutineScope()

    var tab by remember { mutableIntStateOf(0) }
    var sport by remember { mutableStateOf("Все") }
    var serverUrl by remember { mutableStateOf(storage.getServerUrl()) }
    var serverConnected by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var fixtures by remember { mutableStateOf(fallbackFixtures) }
    var historyList by remember { mutableStateOf(storage.getHistory()) }

    fun refreshFromServer(url: String) {
        scope.launch {
            val api = createApi(url)
            if (api != null) {
                try {
                    val health = api.health()
                    serverConnected = health.status == "ok"
                    val res = api.getMatches()
                    if (res.matches.isNotEmpty()) {
                        fixtures = res.matches.map { m ->
                            val icon = when (m.sport) {
                                "football" -> "⚽"
                                "hockey" -> "🏒"
                                "basketball" -> "🏀"
                                else -> "🏅"
                            }
                            Fixture(
                                id = m.id,
                                sport = icon,
                                matchup = "${m.home} — ${m.away}",
                                league = "${m.competition} (${res.mode})",
                                start = m.start_time ?: "Скоро",
                                market = "Ожидание рынка",
                                status = if (m.data_complete) "READY" else "INSUFFICIENT_DATA",
                                explanation = if (m.data_complete) "Данные получены с сервера." else "Сервер: недостаточно статистики для прогноза.",
                                isDemo = res.mode == "demo"
                            )
                        }
                    }
                } catch (e: Exception) {
                    serverConnected = false
                    fixtures = fallbackFixtures
                }
            } else {
                serverConnected = false
            }
        }
    }

    LaunchedEffect(Unit) { refreshFromServer(serverUrl) }

    if (showSettings) {
        var tempUrl by remember { mutableStateOf(serverUrl) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            containerColor = Panel,
            title = { Text("Настройки сервера API", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Укажите адрес запущенного FastAPI-бэкенда (например, http://192.168.1.50:8000/):", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(
                        value = tempUrl,
                        onValueChange = { tempUrl = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    serverUrl = tempUrl
                    storage.saveServerUrl(tempUrl)
                    refreshFromServer(tempUrl)
                    showSettings = false
                }) { Text("Сохранить и проверить") }
            },
            dismissButton = {
                TextButton(onClick = { showSettings = false }) { Text("Отмена", color = Muted) }
            }
        )
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Green,
            onPrimary = Bg,
            onBackground = Color(0xFFF1F5F7),
            onSurface = Color(0xFFF1F5F7)
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Green) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главная") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.SportsSoccer, null) }, label = { Text("Матчи") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Psychology, null) }, label = { Text("AI-анализ") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("История") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Header(isOnline = serverConnected, onOpenSettings = { showSettings = true })
                when (tab) {
                    0 -> HomeScreen(
                        fixtures = fixtures,
                        historyCount = historyList.size,
                        isOnline = serverConnected,
                        onOpenMatches = { tab = 1 },
                        onRefresh = { refreshFromServer(serverUrl) }
                    )
                    1 -> MatchesScreen(fixtures = fixtures, sport = sport, onSport = { sport = it })
                    2 -> AnalysisScreen(
                        serverUrl = serverUrl,
                        onSaved = { newItem ->
                            storage.addHistory(newItem)
                            historyList = storage.getHistory()
                        }
                    )
                    else -> HistoryScreen(
                        items = historyList,
                        onClear = {
                            storage.clearHistory()
                            historyList = emptyList()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun Header(isOnline: Boolean, onOpenSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Color(0xFF183C32), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Bolt, null, tint = Green, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("BETSCOUT AI", fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("PERSONAL SPORTS INTELLIGENCE", fontSize = 9.sp, color = Muted, letterSpacing = 1.sp)
        }
        Surface(
            color = if (isOnline) Color(0xFF1B4332) else Color(0xFF3A3020),
            shape = RoundedCornerShape(50)
        ) {
            Text(
                text = if (isOnline) "API ONLINE" else "OFFLINE",
                color = if (isOnline) Green else Color(0xFFFFCF75),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Настройки сервера", tint = Muted)
        }
    }
}

@Composable
private fun HomeScreen(
    fixtures: List<Fixture>,
    historyCount: Int,
    isOnline: Boolean,
    onOpenMatches: () -> Unit,
    onRefresh: () -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Text("Добро пожаловать", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Анализируем данные и фильтруем слабые события.", color = Muted, fontSize = 13.sp)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Матчи в ленте", "${fixtures.size}", if (isOnline) "с сервера" else "локально", Modifier.weight(1f))
                MetricCard("Мои разборы", "$historyCount", "сохранено", Modifier.weight(1f))
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, null, tint = Green)
                        Spacer(Modifier.width(8.dp))
                        Text("Статус системы", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = onRefresh) { Text("Обновить", color = Green, fontSize = 12.sp) }
                    }
                    Text(
                        if (isOnline) "Связь с FastAPI-сервером активна. Купоны отправляются на анализ и сохраняются в БД."
                        else "Работает автономный режим (OCR и локальная история доступны). Нажмите шестерёнку сверху для ввода IP сервера.",
                        color = Muted,
                        fontSize = 12.sp
                    )
                }
            }
        }
        item {
            Text("Ближайшие события", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        items(fixtures.take(2)) { FixtureCard(it) }
        item {
            OutlinedButton(onClick = onOpenMatches, modifier = Modifier.fillMaxWidth()) { Text("Открыть все матчи") }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, hint: String, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green)
            Text(hint, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun MatchesScreen(fixtures: List<Fixture>, sport: String, onSport: (String) -> Unit) {
    Text("Матчи", fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Все", "Футбол", "Хоккей", "Баскетбол").forEach {
            FilterChip(selected = sport == it, onClick = { onSport(it) }, label = { Text(it) })
        }
    }
    Spacer(Modifier.height(8.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
        items(fixtures.filter {
            sport == "Все" || when (sport) {
                "Футбол" -> it.sport == "⚽"
                "Хоккей" -> it.sport == "🏒"
                else -> it.sport == "🏀"
            }
        }) { FixtureCard(it) }
    }
}

@Composable
private fun FixtureCard(fixture: Fixture) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fixture.sport, fontSize = 19.sp)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(fixture.matchup, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("${fixture.league} · ${fixture.start}", color = Muted, fontSize = 11.sp)
                }
                if (fixture.isDemo) {
                    Text("DEMO", color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Рынок: ${fixture.market}", fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Surface(color = Color(0xFF3A3020), shape = RoundedCornerShape(8.dp)) {
                Text(
                    if (fixture.status == "INSUFFICIENT_DATA") "НЕДОСТАТОЧНО ДАННЫХ" else fixture.status,
                    color = Color(0xFFFFCF75),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(fixture.explanation, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AnalysisScreen(serverUrl: String, onSaved: (SavedAnalysis) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var bookmaker by remember { mutableStateOf("Fonbet") }
    var sport by remember { mutableStateOf("Футбол") }
    var match by remember { mutableStateOf("") }
    var market by remember { mutableStateOf("") }
    var odds by remember { mutableStateOf("") }
    var rawOcrText by remember { mutableStateOf("") }
    var isScanning by remember { mutableStateOf(false) }
    var isSending by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("Загрузите скриншот купона или заполните поля вручную.") }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            isScanning = true
            notice = "Сканируем текст со скриншота..."
            try {
                val image = InputImage.fromFilePath(context, uri)
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        isScanning = false
                        val fullText = visionText.text
                        rawOcrText = fullText
                        if (fullText.isBlank()) {
                            notice = "Текст на изображении не найден. Заполните вручную."
                        } else {
                            if (fullText.contains("Лига Ставок", ignoreCase = true) || fullText.contains("Liga Stavok", ignoreCase = true)) {
                                bookmaker = "Лига Ставок"
                            } else if (fullText.contains("Fonbet", ignoreCase = true) || fullText.contains("Фонбет", ignoreCase = true)) {
                                bookmaker = "Fonbet"
                            }

                            val oddsRegex = Regex("""\b([1-9]\d?[.,]\d{2})\b""")
                            val foundOdds = oddsRegex.find(fullText)?.groupValues?.get(1)?.replace(",", ".")
                            if (foundOdds != null) odds = foundOdds

                            val lines = fullText.lines().map { it.trim() }.filter { it.length > 5 }
                            val matchLine = lines.firstOrNull { it.contains(" — ") || it.contains(" - ") || it.contains(" vs ", ignoreCase = true) }
                            if (matchLine != null) match = matchLine

                            notice = "Скриншот распознан! Проверьте и при необходимости поправьте поля ниже."
                        }
                    }
                    .addOnFailureListener {
                        isScanning = false
                        notice = "Ошибка при распознавании изображения."
                    }
            } catch (e: Exception) {
                isScanning = false
                notice = "Не удалось открыть файл изображения."
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Text("AI-анализ", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("OCR-сканер купонов + расчёт вероятности.", color = Muted, fontSize = 13.sp)
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1. Сканер скриншота (OCR)", fontWeight = FontWeight.Bold)
                    Button(
                        onClick = { imagePicker.launch("image/*") },
                        enabled = !isScanning,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.DocumentScanner, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isScanning) "Распознавание..." else "Выбрать скриншот купона")
                    }
                    if (rawOcrText.isNotBlank()) {
                        Text("Распознанный текст:", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(rawOcrText.take(200) + if (rawOcrText.length > 200) "..." else "", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("2. Параметры купона", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Fonbet", "Лига Ставок").forEach {
                            FilterChip(selected = bookmaker == it, onClick = { bookmaker = it }, label = { Text(it) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Футбол", "Хоккей", "Баскетбол").forEach {
                            FilterChip(selected = sport == it, onClick = { sport = it }, label = { Text(it) })
                        }
                    }
                    OutlinedTextField(value = match, onValueChange = { match = it }, label = { Text("Матч (Команда А — Команда Б)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = market, onValueChange = { market = it }, label = { Text("Рынок (например, ТБ 2.5 или П1)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = odds, onValueChange = { odds = it }, label = { Text("Коэффициент (например, 1.85)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                    Button(
                        enabled = !isSending,
                        onClick = {
                            val parsedOdds = odds.replace(",", ".").toDoubleOrNull()
                            if (match.isBlank() || market.isBlank() || parsedOdds == null || parsedOdds <= 1.0) {
                                notice = "Ошибка: заполните матч, рынок и коэффициент больше 1.00."
                                return@Button
                            }
                            isSending = true
                            scope.launch {
                                val apiSport = when (sport) {
                                    "Футбол" -> "football"
                                    "Хоккей" -> "hockey"
                                    else -> "basketball"
                                }
                                val apiBk = if (bookmaker == "Fonbet") "Fonbet" else "LigaStavok"
                                val impliedProb = String.format(Locale.US, "%.1f", (1.0 / parsedOdds) * 100.0)
                                var resultNote = "Вменённая вероятность рынка: $impliedProb%. Сохранено локально."
                                var statusLabel = "LOCAL_SAVED"

                                val api = createApi(serverUrl)
                                if (api != null) {
                                    try {
                                        val res = api.sendCouponDraft(
                                            CouponDraftRequest(
                                                bookmaker = apiBk,
                                                sport = apiSport,
                                                match = match,
                                                market = market,
                                                odds = parsedOdds,
                                                source = if (rawOcrText.isNotBlank()) "screenshot" else "manual"
                                            )
                                        )
                                        if (res.accepted) {
                                            statusLabel = res.decision ?: "SERVER_ACCEPTED"
                                            resultNote = res.note
                                        }
                                    } catch (e: Exception) {
                                        // Fallback к локальному расчёту
                                    }
                                }

                                val sdf = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
                                onSaved(
                                    SavedAnalysis(
                                        id = UUID.randomUUID().toString(),
                                        date = sdf.format(Date()),
                                        bookmaker = bookmaker,
                                        sport = sport,
                                        match = match,
                                        market = market,
                                        odds = parsedOdds,
                                        status = statusLabel,
                                        note = resultNote
                                    )
                                )
                                isSending = false
                                notice = "Готово! $resultNote"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isSending) "Анализируем..." else "Проанализировать и сохранить")
                    }
                    Text(notice, color = Green, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(items: List<SavedAnalysis>, onClear: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text("История (${items.size})", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (items.isNotEmpty()) {
            TextButton(onClick = onClear) { Text("Очистить", color = Color(0xFFFF7575)) }
        }
    }
    Spacer(Modifier.height(8.dp))
    if (items.isEmpty()) {
        Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Icon(Icons.Default.History, null, tint = Green)
                Spacer(Modifier.height(8.dp))
                Text("История пока пуста", fontWeight = FontWeight.Bold)
                Text("Проверенные купоны из вкладки «AI-анализ» автоматически появятся здесь.", color = Muted, fontSize = 12.sp)
            }
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(items) { item ->
                Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${item.bookmaker} · ${item.sport}", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(item.date, color = Muted, fontSize = 11.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(item.match, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Рынок: ${item.market}  |  Кэф: ${item.odds}", fontSize = 13.sp, color = Color.White)
                        Spacer(Modifier.height(6.dp))
                        Text(item.note, color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
