# BETSCOUT AI — v0.4.0

Android client (Kotlin + Jetpack Compose + ML Kit OCR + Retrofit) + FastAPI backend with SQLite persistence.

## Included in v0.4.0
- **Android App:**
  - Offline ML Kit OCR scanner for Fonbet and Liga Stavok coupon screenshots.
  - Local history storage (`SharedPreferences`) + server sync.
  - Configurable FastAPI backend URL via in-app Settings dialog.
  - Real API integration (`/health`, `/matches`, `/coupon/draft`, `/analyze`, `/history`).
- **FastAPI Backend:**
  - SQLite persistence (`betscout.db`) for coupon drafts and analysis history.
  - Enhanced heuristic & market-edge analysis engine (`/analyze` and `/coupon/draft`).
  - Provider registry (`/providers`) ready for API-SPORTS, The Odds API, and BALLDONTLIE keys.

## Run backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Build APK via GitHub Actions
See `INSTALL_ON_PHONE_RU.md` for step-by-step instructions.
