from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .demo import demo_matches
from .models import AnalysisRequest, CouponDraft
from .analysis import analyze, evaluate_coupon
from .providers import provider_status
from .db import init_db, save_coupon_record, get_history_records

app = FastAPI(
    title="BETSCOUT AI API",
    version="0.4.0",
    description="Sports analysis service with SQLite persistence."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    init_db()

@app.get("/health")
def health():
    return {"status": "ok", "service": "betscout-ai", "mode": "active"}

@app.get("/matches")
def matches(sport: str | None = None):
    items = demo_matches()
    if sport:
        items = [m for m in items if m.sport == sport]
    return {"mode": "demo", "matches": items}

@app.post("/analyze")
def analyze_match(request: AnalysisRequest):
    return analyze(request)

@app.get("/history")
def history():
    return {"items": get_history_records()}

@app.get("/providers")
def providers():
    return {"providers": provider_status()}

@app.post("/coupon/draft")
def coupon_draft(draft: CouponDraft):
    eval_res = evaluate_coupon(draft)
    record_id = save_coupon_record(
        bookmaker=draft.bookmaker,
        sport=draft.sport,
        match_name=draft.match,
        market=draft.market,
        odds=draft.odds,
        source=draft.source,
        implied_prob=eval_res["implied_probability"],
        decision=eval_res["decision"],
        note=eval_res["note"]
    )
    return {
        "accepted": True,
        "persisted": True,
        "record_id": record_id,
        "implied_probability": eval_res["implied_probability"],
        "decision": eval_res["decision"],
        "note": eval_res["note"]
    }
