from dataclasses import dataclass
import os

@dataclass(frozen=True)
class Provider:
    name: str
    sports: tuple[str, ...]
    role: str
    mode: str
    notes: str

PROVIDERS = (
    Provider(
        name="API-SPORTS",
        sports=("football", "hockey", "basketball"),
        role="primary fixtures, scores, results and available statistics",
        mode="free-first; upgrade only where quotas/coverage require",
        notes="100 requests/day free tier per sport."
    ),
    Provider(
        name="The Odds API",
        sports=("football", "hockey", "basketball"),
        role="secondary odds and market comparison",
        mode="optional paid add-on",
        notes="Verify bookmaker coverage."
    ),
    Provider(
        name="BALLDONTLIE",
        sports=("basketball", "hockey", "football"),
        role="optional cross-check for supported leagues",
        mode="free-first",
        notes="League/endpoint-limited."
    ),
)

def provider_status() -> list[dict]:
    return [
        {
            "name": p.name,
            "sports": list(p.sports),
            "role": p.role,
            "mode": p.mode,
            "configured": bool(os.getenv({
                "API-SPORTS": "API_SPORTS_KEY",
                "The Odds API": "ODDS_API_KEY",
                "BALLDONTLIE": "BALLDONTLIE_API_KEY",
            }[p.name])),
        }
        for p in PROVIDERS
    ]
