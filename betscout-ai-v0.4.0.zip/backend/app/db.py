import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "betscout.db"

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS coupon_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                bookmaker TEXT NOT NULL,
                sport TEXT NOT NULL,
                match_name TEXT NOT NULL,
                market TEXT NOT NULL,
                odds REAL NOT NULL,
                source TEXT NOT NULL,
                implied_prob REAL NOT NULL,
                decision TEXT NOT NULL,
                note TEXT NOT NULL
            )
        """)
        conn.commit()

def save_coupon_record(bookmaker: str, sport: str, match_name: str, market: str, odds: float, source: str, implied_prob: float, decision: str, note: str) -> int:
    init_db()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute(
            "INSERT INTO coupon_history (created_at, bookmaker, sport, match_name, market, odds, source, implied_prob, decision, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (now, bookmaker, sport, match_name, market, odds, source, implied_prob, decision, note)
        )
        conn.commit()
        return cur.lastrowid

def get_history_records(limit: int = 50) -> list[dict]:
    init_db()
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM coupon_history ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
