from .models import Match

def demo_matches():
    return [
        Match(id="demo-football-1", sport="football", home="Example FC", away="Sample United",
              competition="Demo League", start_time="19:30", data_complete=False),
        Match(id="demo-hockey-1", sport="hockey", home="Demo Hawks", away="Test Bears",
              competition="Demo Ice League", start_time="20:00", data_complete=False),
        Match(id="demo-basketball-1", sport="basketball", home="Sample City", away="Example Lakers",
              competition="Demo Basketball League", start_time="21:15", data_complete=False),
    ]
