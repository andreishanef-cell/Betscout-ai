from .models import AnalysisRequest, AnalysisResponse, CouponDraft

def analyze(req: AnalysisRequest) -> AnalysisResponse:
    m = req.match
    reasons = []
    if not m.data_complete:
        reasons.append("Не подтверждена полнота исходных данных.")
    if not m.data_updated_at:
        reasons.append("Нет времени последнего обновления данных.")
    if not m.stats:
        reasons.append("Нет статистики команд или игроков.")
    if not m.odds:
        reasons.append("Нет актуального коэффициента для сравнения с модельной оценкой.")

    if reasons:
        decision = "INSUFFICIENT_DATA"
        confidence = None
    else:
        decision = "REVIEW"
        confidence = None
        reasons.append("Данные получены; требуется проверка преимущества над рынком.")

    return AnalysisResponse(
        match_id=m.id,
        market=req.market,
        decision=decision,
        confidence=confidence,
        reasons=reasons
    )

def evaluate_coupon(draft: CouponDraft) -> dict:
    implied_prob = round((1.0 / draft.odds) * 100.0, 2)
    if draft.odds < 1.35:
        decision = "LOW_ODDS_WARNING"
        note = f"Вменённая вероятность {implied_prob}%. Низкий коэффициент: высокая чувствительность к марже букмекера."
    elif draft.odds > 4.50:
        decision = "HIGH_VARIANCE"
        note = f"Вменённая вероятность {implied_prob}%. Высокий риск (аутсайдер/сложный рынок), требуется строгая проверка составов."
    else:
        decision = "SAVED_FOR_REVIEW"
        note = f"Купон принят и сохранён в БД. Вменённая вероятность рынка: {implied_prob}%."
    return {
        "implied_probability": implied_prob,
        "decision": decision,
        "note": note
    }
