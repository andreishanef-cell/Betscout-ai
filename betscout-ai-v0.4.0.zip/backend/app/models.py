from pydantic import BaseModel, Field
from typing import Literal

Sport = Literal["football", "hockey", "basketball"]

class Match(BaseModel):
    id: str
    sport: Sport
    home: str
    away: str
    competition: str = "Unknown"
    start_time: str | None = None
    data_complete: bool = False
    data_updated_at: str | None = None
    odds: dict[str, float] = Field(default_factory=dict)
    stats: dict[str, float] = Field(default_factory=dict)

class AnalysisRequest(BaseModel):
    match: Match
    market: str

class AnalysisResponse(BaseModel):
    match_id: str
    market: str
    decision: Literal["INSUFFICIENT_DATA", "REVIEW", "NO_EDGE"]
    confidence: float | None = None
    reasons: list[str]
    disclaimer: str = "Аналитическая оценка не гарантирует исход и не является советом ставить."

class CouponDraft(BaseModel):
    bookmaker: Literal["Fonbet", "LigaStavok"]
    sport: Sport
    match: str = Field(min_length=3, max_length=200)
    market: str = Field(min_length=2, max_length=120)
    odds: float = Field(gt=1.0, le=1000.0)
    source: Literal["manual", "screenshot"] = "manual"
